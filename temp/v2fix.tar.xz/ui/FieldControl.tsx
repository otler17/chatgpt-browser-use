import { Button, InlineNotification, NumberInput, Select, SelectItem, Tag, TextArea, TextInput, Toggle } from '@carbon/react';
import { useMemo, useState } from 'react';
import type { JsonValue, RuntimeFieldContract, StudioFieldManifestEntry } from '../contracts/types';
import type { FieldAvailability } from '../domain/dependencies/availability';
import type { ValidationIssue } from '../domain/validation/issues';
import { ScenarioStudioServiceClient } from '../services/local-service-client';
import { displayValue, fieldHelp, fieldLabel, parseScalar, parseStructured } from './field-format';
import { MatrixEditor, PathListEditor, VectorEditor } from './StructuredScalarEditors';

interface Props {
  field: StudioFieldManifestEntry; contract: RuntimeFieldContract; value: JsonValue; availability: FieldAvailability;
  onChange: (value: JsonValue) => void; onReset?: (()=>void) | undefined; service?: ScenarioStudioServiceClient | null | undefined; issues?: ValidationIssue[] | undefined;
}
function equal(a:JsonValue|undefined,b:JsonValue|undefined):boolean{return JSON.stringify(a??null)===JSON.stringify(b??null);}

export function FieldControl({ field, contract, value, availability, onChange, onReset, service, issues = [] }: Props) {
  const id = `runtime-field-${field.name}`; const label = field.label || fieldLabel(field.name); const helper = fieldHelp(field); const disabled = availability.state !== 'editable';
  const [localError, setLocalError] = useState(''); const choices = useMemo(() => contract.ui_choices || contract.runtime_choices || [], [contract]);
  const changed = contract.has_default && !equal(value, contract.default);
  const structured = field.control === 'json' || field.control === 'color-rgba' || field.control === 'entity-collection' || field.control === 'composite';
  const commitText = (text: string) => { try { onChange(structured ? parseStructured(text) : parseScalar(text, contract)); setLocalError(''); } catch (error) { setLocalError(error instanceof Error ? error.message : String(error)); } };
  const browseList = async():Promise<string[]>=>{if(!service)return[];const result=await service.selectPath({field_name:field.name,path_kind:field.path?.kind||contract.path_kind||'input_file',current_value:'',accept:''});return Array.isArray(result.paths)?result.paths.map(String):typeof result.paths==='string'?[result.paths]:[];};
  let control: React.ReactNode;
  if (field.control === 'hidden') control = <div className="ss-readonly-value">Compatibility value: <code>{displayValue(value)}</code></div>;
  else if (field.control === 'read-only' || availability.state === 'read-only') control = <TextArea id={id} labelText={label} value={displayValue(value)} readOnly rows={Math.min(8, Math.max(2, displayValue(value).split('\n').length))} helperText={helper} />;
  else if (field.control === 'toggle') control = <Toggle id={id} labelText={label} labelA="Off" labelB="On" toggled={value === true} disabled={disabled} onToggle={(checked: boolean) => onChange(checked)} />;
  else if (field.control === 'number') control = <NumberInput id={id} label={`${label}${field.unit?` (${field.unit})`:''}`} value={typeof value === 'number' ? value : Number(value) || 0} disabled={disabled} invalid={!!localError} invalidText={localError} helperText={helper} onChange={(_event: unknown, state: { value: string | number }) => commitText(String(state.value))} />;
  else if (field.control === 'select' && choices.length) {
    const tokenFor = (choice: JsonValue) => JSON.stringify(choice);
    control = <Select id={id} labelText={label} value={tokenFor(value)} disabled={disabled} helperText={helper} onChange={(event: React.ChangeEvent<HTMLSelectElement>) => {
      const selected = choices.find((choice) => tokenFor(choice) === event.target.value);
      if (selected !== undefined) onChange(selected);
    }}>{choices.map((choice) => <SelectItem key={tokenFor(choice)} value={tokenFor(choice)} text={String(choice)} />)}</Select>;
  }
  else if (field.control === 'path-list') control = <PathListEditor id={id} label={label} helper={helper} value={value} disabled={disabled} onChange={onChange} {...(service ? { onBrowse: browseList } : {})} />;
  else if (field.control === 'path') { const pathKind = field.path?.kind || contract.path_kind || 'input_file'; const output = field.path?.direction === 'write' || contract.path_direction === 'write'; control = <div className="ss-path-control"><TextInput id={id} labelText={label} value={displayValue(value)} disabled={disabled} invalid={!!localError} invalidText={localError} helperText={`${helper}${output?' Output is normalized to a managed run-relative destination.':''}`} onChange={(event: React.ChangeEvent<HTMLInputElement>) => onChange(event.target.value)} /><Button kind="secondary" size="sm" disabled={disabled || !service} onClick={async () => { if (!service) return; try { const result = output ? await service.managedOutput({ field_name: field.name, path_kind: pathKind, artifact_category: field.path?.artifact_category || contract.artifact_category || '', requested_value: displayValue(value) }) : await service.selectPath({ field_name: field.name, path_kind: pathKind, current_value: displayValue(value), accept: '' }); const next = output ? result.logical_value : result.paths; if (typeof next === 'string') onChange(next); else if (Array.isArray(next)) onChange(String(next[0] || '')); setLocalError(''); } catch (error) { setLocalError(error instanceof Error ? error.message : String(error)); } }}>{output ? 'Use managed path' : 'Browse'}</Button></div>; }
  else if (field.control === 'vector' || field.control === 'color-rgba') control = <VectorEditor id={id} label={label} helper={helper} value={value} disabled={disabled} onChange={onChange} />;
  else if (field.control === 'matrix') control = <MatrixEditor id={id} label={label} helper={helper} value={value} disabled={disabled} onChange={onChange} />;
  else if (structured) control = <TextArea key={displayValue(value)} id={id} labelText={label} defaultValue={displayValue(value)} disabled={disabled} invalid={!!localError} invalidText={localError} helperText={`${helper} Structured JSON.`} rows={Math.min(10, Math.max(3, displayValue(value).split('\n').length))} onBlur={(event: React.FocusEvent<HTMLTextAreaElement>) => commitText(event.target.value)} />;
  else control = <TextInput id={id} labelText={label} value={displayValue(value)} disabled={disabled} invalid={!!localError} invalidText={localError} helperText={helper} onChange={(event: React.ChangeEvent<HTMLInputElement>) => onChange(event.target.value)} onBlur={(event: React.FocusEvent<HTMLInputElement>) => commitText(event.target.value)} />;

  return <div className="ss-field" data-field={field.name} data-workspace-section={field.section} data-presentation-level={field.presentation}>{control}<div className="ss-field-meta"><code>{field.name}</code>{field.unit&&<Tag size="sm" type="cool-gray">{field.unit}</Tag>}{changed&&<Tag size="sm" type="blue">Changed</Tag>}{changed&&onReset&&<Button kind="ghost" size="sm" disabled={disabled} onClick={onReset}>Reset default</Button>}</div>{availability.state === 'disabled' && <InlineNotification lowContrast hideCloseButton kind="info" title="Unavailable" subtitle={availability.reason} />}{issues.map((issue) => <InlineNotification key={issue.id} lowContrast hideCloseButton kind={issue.severity === 'error' ? 'error' : issue.severity === 'warning' ? 'warning' : 'info'} title={issue.code || `${issue.layer} validation`} subtitle={issue.message} />)}</div>;
}
