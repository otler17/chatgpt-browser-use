import { NumberInput, Select, SelectItem, Stack, TextInput, Toggle } from '@carbon/react';
import type { JsonValue } from '../contracts/types';

interface Props {
  idPrefix: string;
  schema: Record<string, JsonValue> | null;
  value: Record<string, JsonValue>;
  onChange: (next: Record<string, JsonValue>) => void;
}

function record(value: JsonValue | undefined): Record<string, JsonValue> | null {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, JsonValue> : null;
}
function scalarDefault(property: Record<string, JsonValue>): JsonValue {
  if ('default' in property) return property.default ?? null;
  if (property.type === 'boolean') return false;
  if (property.type === 'number' || property.type === 'integer') return 0;
  return '';
}

/** Render the subset of JSON Schema parameter contracts that can be safely authored as scalars.
 * Complex parameter objects remain preserved in canonical state and are editable through their
 * owning algorithm package UI when a richer schema-specific editor is required.
 */
export function AlgorithmParametersEditor({ idPrefix, schema, value, onChange }: Props) {
  const properties = record(schema?.properties);
  if (!properties || !Object.keys(properties).length) return <p>No configurable parameters are published for this algorithm.</p>;
  const set = (key: string, next: JsonValue) => onChange({ ...value, [key]: next });
  return <Stack gap={4}>{Object.entries(properties).map(([key, raw]) => {
    const property = record(raw);
    if (!property) return null;
    const id = `${idPrefix}-${key}`;
    const title = String(property.title || key.replaceAll('_', ' '));
    const helper = String(property.description || '');
    const current = key in value ? value[key]! : scalarDefault(property);
    const choices = Array.isArray(property.enum) ? property.enum : [];
    if (choices.length) {
      const tokenFor = (item: JsonValue) => JSON.stringify(item);
      return <Select key={key} id={id} labelText={title} helperText={helper} value={tokenFor(current)} onChange={(event: React.ChangeEvent<HTMLSelectElement>) => {
        const selected = choices.find((item) => tokenFor(item) === event.target.value);
        if (selected !== undefined) set(key, selected);
      }}>{choices.map((item) => <SelectItem key={tokenFor(item)} value={tokenFor(item)} text={String(item)} />)}</Select>;
    }
    if (property.type === 'boolean') return <Toggle key={key} id={id} labelText={title} labelA="Off" labelB="On" toggled={current === true} onToggle={(checked: boolean) => set(key, checked)} />;
    if (property.type === 'number' || property.type === 'integer') {
      const min = typeof property.minimum === 'number' ? property.minimum : undefined;
      const max = typeof property.maximum === 'number' ? property.maximum : undefined;
      return <NumberInput key={key} id={id} label={title} helperText={helper} value={Number(current) || 0} {...(min !== undefined ? { min } : {})} {...(max !== undefined ? { max } : {})} onChange={(_event: unknown, state: { value: string | number }) => { const parsed = Number(state.value); if (Number.isFinite(parsed)) set(key, property.type === 'integer' ? Math.trunc(parsed) : parsed); }} />;
    }
    if (property.type === 'string' || !property.type) return <TextInput key={key} id={id} labelText={title} helperText={helper} value={String(current ?? '')} onChange={(event: React.ChangeEvent<HTMLInputElement>) => set(key, event.target.value)} />;
    return <div key={key}><strong>{title}</strong><p>Complex parameter type <code>{String(property.type)}</code> is preserved but not edited by the generic scalar parameter editor.</p></div>;
  })}</Stack>;
}
