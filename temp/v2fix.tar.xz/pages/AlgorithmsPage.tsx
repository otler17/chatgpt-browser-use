import {
  Accordion, AccordionItem, Button, Column, Grid, InlineLoading, InlineNotification, Search, Select, SelectItem, Stack,
  Table, TableBody, TableCell, TableContainer, TableHead, TableHeader, TableRow, Tag, TextInput, Tile,
} from '@carbon/react';
import { useEffect, useMemo, useState } from 'react';
import { useBootstrap } from '../app/Bootstrap';
import type { JsonValue } from '../contracts/types';
import {
  ADCS_MODE_MATRIX_SPEC, composeAuthoritativeModeProfile, createSourceModeProfile, validateModeProfile,
  type AdcsModeProfile,
} from '../domain/algorithms/mode-profile';
import { profileFromDraft } from '../domain/algorithms/profile-authority';
import { useScenarioState, useScenarioStore } from '../store';
import { RouteWorkspace } from '../ui/RouteWorkspace';
import { AlgorithmParametersEditor } from '../ui/AlgorithmParametersEditor';

const CATEGORY_LABELS: Record<string, string> = {
  executive_policy: 'Executive', guidance: 'Guidance', reference_shaper: 'Reference shaper', body_torque_controller: 'Torque controller',
  rw_allocator: 'RW allocator', magnetic_controller: 'Magnetic controller', magnetic_allocator: 'Magnetic allocator',
};
function record(value: JsonValue | undefined): Record<string, JsonValue> | null { return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, JsonValue> : null; }
function keyOf(entry: Record<string, JsonValue>): string { return `${String(entry.algorithm_id || '')}:${String(entry.version || '')}:${String(entry.fingerprint || entry.package_sha256 || '')}`; }

export function AlgorithmsPage() {
  const { service } = useBootstrap();
  const store = useScenarioStore();
  const { draft, runtimeConfig } = useScenarioState((state) => ({ draft: state.draft, runtimeConfig: state.draft.runtimeConfig }));
  const [catalog, setCatalog] = useState<Record<string, JsonValue> | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [profile, setProfile] = useState<AdcsModeProfile>(() => profileFromDraft(draft));
  useEffect(() => {
    const c = new AbortController(); setLoading(true);
    void service.algorithmCatalog(c.signal).then((value) => { setCatalog(value); setError(''); }).catch((reason) => setError(reason instanceof Error ? reason.message : String(reason))).finally(() => setLoading(false));
    return () => c.abort();
  }, [service]);
  useEffect(() => { setProfile(profileFromDraft(draft)); }, [draft.bundleAuthority]);

  const published = Array.isArray(catalog?.entries) ? catalog.entries.filter((item): item is Record<string, JsonValue> => !!item && typeof item === 'object' && !Array.isArray(item)) : [];
  const embedded = ADCS_MODE_MATRIX_SPEC.catalog.entries;
  const entries = useMemo(() => {
    const byKey = new Map<string, Record<string, JsonValue>>();
    for (const entry of [...embedded, ...published]) byKey.set(keyOf(entry), entry);
    return [...byKey.values()];
  }, [published]);
  const filteredEntries = entries.filter((entry) => {
    const q = query.trim().toLowerCase(); if (!q) return true;
    return ['algorithm_id','category','version','input_contract','output_contract','fingerprint'].some((key) => String(entry[key] || '').toLowerCase().includes(q));
  });
  const authoritative = useMemo(() => composeAuthoritativeModeProfile(profile, runtimeConfig), [profile, runtimeConfig]);
  const profileIssues = useMemo(() => validateModeProfile(authoritative, entries), [authoritative, entries]);

  const commitProfile = async (next: AdcsModeProfile) => {
    const resolved = composeAuthoritativeModeProfile(next, store.getState().draft.runtimeConfig);
    const issues = validateModeProfile(resolved, entries);
    setProfile(next);
    await store.setAdcsModeProfile(resolved, issues.length === 0 && !error);
  };
  const setBinding = (mode: string, category: string, algorithmId: string) => {
    const next = structuredClone(profile);
    next.modes[mode] ||= {};
    if (!algorithmId) delete next.modes[mode]![category];
    else if (algorithmId === '__disabled__') next.modes[mode]![category] = { disabled: true, reason: 'Disabled in Scenario Studio profile' };
    else {
      const entry = entries.find((item) => String(item.algorithm_id || '') === algorithmId && String(item.category || '') === category && (Array.isArray(item.supported_modes) ? item.supported_modes.map(String).includes(mode) : false));
      const prior = next.modes[mode]![category];
      next.modes[mode]![category] = { algorithm_id: algorithmId, parameters: prior?.algorithm_id === algorithmId ? prior.parameters || {} : record(entry?.parameter_defaults) || {} };
    }
    void commitProfile(next);
  };
  const selectedSource = (mode: string, category: string): string => {
    const binding = profile.modes[mode]?.[category];
    if (binding?.disabled) return '__disabled__';
    return String(binding?.algorithm_id || '');
  };
  const available = (mode: string, category: string) => entries.filter((entry) => String(entry.category || '') === category && Array.isArray(entry.supported_modes) && entry.supported_modes.map(String).includes(mode));
  const explicitBindings = useMemo(() => ADCS_MODE_MATRIX_SPEC.modes.flatMap((mode) => Object.entries(profile.modes[mode] || {}).flatMap(([category, binding]) => binding.algorithm_id && !binding.disabled ? [{ mode, category, binding }] : [])), [profile]);
  const updateBindingParameters = (mode: string, category: string, parameters: Record<string, JsonValue>) => {
    const next = structuredClone(profile); const binding = next.modes[mode]?.[category]; if (!binding?.algorithm_id) return;
    binding.parameters = parameters; void commitProfile(next);
  };
  const catalogHeaders = [{ key:'algorithm_id', header:'Algorithm' }, { key:'category', header:'Category' }, { key:'version', header:'Version' }, { key:'contracts', header:'Contracts' }, { key:'modes', header:'Modes' }, { key:'fingerprint', header:'Fingerprint' }];
  const catalogRows = filteredEntries.map((entry, index) => ({ id: `${keyOf(entry)}:${index}`, algorithm_id: String(entry.algorithm_id || ''), category: String(entry.category || ''), version: String(entry.version || ''), contracts: `${String(entry.input_contract || '?')} → ${String(entry.output_contract || '?')}`, modes: Array.isArray(entry.supported_modes) ? entry.supported_modes.join(', ') : '', fingerprint: String(entry.fingerprint || entry.package_sha256 || '').slice(0,16) }));

  return <><section className="ss-workspace"><Grid fullWidth><Column sm={4} md={8} lg={12}><Stack gap={6}><div className="ss-page-heading"><div><h1>Algorithms</h1><p>The ADCS Mode Algorithm Matrix is the authoring authority for the managed <code>astral.adcs_mode_algorithms/v1</code> profile. Published package identity comes from the validated local catalog; developer paths never become scenario identity.</p></div><Tag type={profileIssues.length ? 'red' : 'green'}>{profileIssues.length ? `${profileIssues.length} profile issues` : 'Profile valid'}</Tag></div>
    {error && <InlineNotification lowContrast hideCloseButton kind="warning" title="Published algorithm catalog unavailable" subtitle={`${error} Maintained built-in identities remain visible, but export readiness is blocked until published identities are verified.`} />}
    {loading && <InlineLoading description="Loading validated algorithm catalog…" />}
    <Tile><Stack gap={5}><div className="ss-entity-heading"><div><h2>Mode algorithm profile</h2><p>Empty selections inherit the scenario-composed maintained baseline. Required stages cannot be bypassed; optional stages may be explicitly disabled.</p></div><div className="ss-action-row"><Button kind="tertiary" size="sm" onClick={() => void commitProfile(createSourceModeProfile())}>Reset to scenario baseline</Button><Tag size="sm" type="cool-gray">{ADCS_MODE_MATRIX_SPEC.modes.length} modes</Tag></div></div>
      <div className="ss-field-grid"><TextInput id="adcs-profile-id" labelText="Profile ID" value={profile.profile_id} onChange={(event: React.ChangeEvent<HTMLInputElement>) => setProfile((current) => ({ ...current, profile_id: event.target.value }))} onBlur={() => void commitProfile(profile)} /><TextInput id="adcs-profile-version" labelText="Profile version" value={profile.profile_version} onChange={(event: React.ChangeEvent<HTMLInputElement>) => setProfile((current) => ({ ...current, profile_version: event.target.value }))} onBlur={() => void commitProfile(profile)} /></div>
      {profileIssues.length > 0 && <InlineNotification kind="error" lowContrast hideCloseButton title="Mode profile is blocked" subtitle={profileIssues.slice(0,4).map((issue) => issue.message).join(' · ')} />}
      <div className="ss-algorithm-matrix-wrap"><Table size="sm"><TableHead><TableRow><TableHeader>Mode</TableHeader>{ADCS_MODE_MATRIX_SPEC.categories.map((category) => <TableHeader key={category}>{CATEGORY_LABELS[category] || category}</TableHeader>)}</TableRow></TableHead><TableBody>{ADCS_MODE_MATRIX_SPEC.modes.map((mode) => { const rule = ADCS_MODE_MATRIX_SPEC.rules[mode]!; return <TableRow key={mode}><TableCell><strong>{mode}</strong><br/><small>{rule.required.length} required</small></TableCell>{ADCS_MODE_MATRIX_SPEC.categories.map((category) => { if (!rule.allowed.includes(category)) return <TableCell key={category}><span className="ss-na">Not applicable</span></TableCell>; const inherited = authoritative.modes[mode]?.[category] || authoritative.defaults[category]; return <TableCell key={category}><Select id={`mode-${mode}-${category}`} size="sm" labelText={`${CATEGORY_LABELS[category] || category} for ${mode}`} hideLabel value={selectedSource(mode, category)} onChange={(event: React.ChangeEvent<HTMLSelectElement>) => setBinding(mode, category, event.target.value)}><SelectItem value="" text={`Inherit: ${String(inherited?.algorithm_id || 'unresolved')}`} />{!rule.required.includes(category) && <SelectItem value="__disabled__" text="Disabled / bypass" />}{available(mode, category).map((entry) => <SelectItem key={keyOf(entry)} value={String(entry.algorithm_id)} text={`${String(entry.algorithm_id)} · v${String(entry.version || '?')}`} />)}</Select></TableCell>; })}</TableRow>; })}</TableBody></Table></div>
      {explicitBindings.length > 0 && <section aria-labelledby="algorithm-parameters-heading"><h3 id="algorithm-parameters-heading">Explicit algorithm parameters</h3><p>Only bindings explicitly selected in this scenario appear here. Parameter controls are generated from each published algorithm's JSON Schema; inherited baseline parameters remain runtime-composed.</p><Accordion>{explicitBindings.map(({ mode, category, binding }) => { const entry = entries.find((item) => String(item.algorithm_id || '') === binding.algorithm_id && String(item.category || '') === category); const schema = record(entry?.parameter_schema); return <AccordionItem key={`${mode}:${category}`} title={`${mode} · ${CATEGORY_LABELS[category] || category} · ${binding.algorithm_id}`}><AlgorithmParametersEditor idPrefix={`params-${mode}-${category}`} schema={schema} value={binding.parameters || {}} onChange={(next) => updateBindingParameters(mode, category, next)} /></AccordionItem>; })}</Accordion></section>}
    </Stack></Tile>
    <section><div className="ss-entity-heading"><div><h2>Validated catalog</h2><p>Search published and maintained entries by algorithm, role, contract or fingerprint.</p></div><Button kind="ghost" size="sm" onClick={() => { setLoading(true); void service.refreshAlgorithmCatalog().then((value) => { setCatalog(value); setError(''); }).catch((reason) => setError(reason instanceof Error ? reason.message : String(reason))).finally(() => setLoading(false)); }}>Refresh catalog</Button></div><Search labelText="Search algorithm catalog" placeholder="Algorithm, category, contract, fingerprint…" value={query} onChange={(event: React.ChangeEvent<HTMLInputElement>) => setQuery(event.target.value)} />
      <TableContainer><Table size="md"><TableHead><TableRow>{catalogHeaders.map((header) => <TableHeader key={header.key}>{header.header}</TableHeader>)}</TableRow></TableHead><TableBody>{catalogRows.map((row) => <TableRow key={row.id}><TableCell><strong>{row.algorithm_id}</strong></TableCell><TableCell>{row.category}</TableCell><TableCell>{row.version}</TableCell><TableCell><small>{row.contracts}</small></TableCell><TableCell><small>{row.modes}</small></TableCell><TableCell><code>{row.fingerprint}…</code></TableCell></TableRow>)}</TableBody></Table></TableContainer>
    </section>
  </Stack></Column></Grid></section><RouteWorkspace route="/gnc/algorithms" title="Algorithm execution settings" description="Runtime algorithm execution posture, parameter surfaces, and managed profile integration." service={service} embedded /></>;
}
