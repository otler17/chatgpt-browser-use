import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: '/studio/',
  plugins: [react()],
  build: {
    cssMinify: 'esbuild',
    outDir: 'dist',
    manifest: true,
    sourcemap: false,
    emptyOutDir: true,
    rollupOptions: {
      output: {
        manualChunks(id: string) {
          if (id.includes('three')) return 'visualization-three';
          if (id.includes('@carbon')) return 'carbon';
          if (id.includes('react')) return 'react';
          return undefined;
        },
      },
    },
  },
  server: {
    host: '127.0.0.1',
    port: 5173,
    proxy: { '/api': 'http://127.0.0.1:8070' },
  },
});
