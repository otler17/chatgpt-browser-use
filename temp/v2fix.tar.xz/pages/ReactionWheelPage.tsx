import { Button, Column, Grid, Modal, NumberInput, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableHeader, TableRow, Tag, TextInput, Tile, Toggle } from '@carbon/react';
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { JsonValue } from '../contracts/types';
import { addReactionWheel, duplicateReactionWheel, moveReactionWheel, removeHardwareMapping, removeReactionWheel, selectReactionWheelWorkspaceModel, replaceReactionWheelPlantRows, upsertHardwareMapping, DEFAULT_HARDWARE_REACTION_WHEEL, type HardwareReactionWheelRow, type ReactionWheelPlantRow } from '../domain/entities/reaction-wheel/model';
import entityMaps from '../domain/entities/entity-field-maps.generated.json';
import { useBootstrap } from '../app/Bootstrap';
import { useScenarioState, useScenarioStore } from '../store';
import { RouteWorkspace } from '../ui/RouteWorkspace';
import { StructuredCollectionEditor } from '../ui/StructuredCollectionEditor';
import { SemanticFieldGroup } from '../ui/SemanticFieldGroup';
import { EntityFamilyFieldGroups } from '../ui/EntityFamilyFieldGroups';

const headers = [{ key: 'label', header: 'Wheel' }, { key: 'axis', header: 'Spin axis B' }, { key: 'torque', header: 'Max torque (N·m)' }, { key: 'speed', header: 'Initial speed (rpm)' }, { key: 'hardware', header: 'HIL mapping' }];
function vectorText(value: number[]): string { return value.join(', '); }
function parseVector(value: string): number[] { const row = value.split(',').map(Number); if (row.length !== 3 || row.some((item) => !Number.isFinite(item))) throw new Error('Enter three comma-separated numbers.'); return row; }


function HardwareMappingEditor({ value, onPatch }: { value: HardwareReactionWheelRow; onPatch: (patch: HardwareReactionWheelRow) => void }) {
  const keys = Object.keys({ ...DEFAULT_HARDWARE_REACTION_WHEEL, ...value }).filter((key) => key !== 'wheel_index').sort();
  return <div className="ss-structured-fields">{keys.map((key) => { const current=value[key] ?? DEFAULT_HARDWARE_REACTION_WHEEL[key] ?? null; const id=`rw-hardware-${key}`; if(typeof current==='boolean') return <Toggle key={key} id={id} labelText={key.replaceAll('_',' ')} labelA="Off" labelB="On" toggled={current} onToggle={(checked:boolean)=>onPatch({[key]:checked})} />; if(typeof current==='number') return <NumberInput key={key} id={id} label={key.replaceAll('_',' ')} value={current} onChange={(_event:unknown,state:{value:string|number})=>{const n=Number(state.value);if(Number.isFinite(n))onPatch({[key]:n});}} />; return <TextInput key={key} id={id} labelText={key.replaceAll('_',' ')} value={String(current??'')} onChange={(event:React.ChangeEvent<HTMLInputElement>)=>onPatch({[key]:event.target.value})} />; })}</div>;
}

export function ReactionWheelPage() {
  const store = useScenarioStore();
  const navigate = useNavigate();
  const { service } = useBootstrap();
  const { draft, schema } = useScenarioState((state) => ({ draft: state.draft, schema: state.contracts.runtime.value }));
  const model = useMemo(() => selectReactionWheelWorkspaceModel(draft), [draft]);
  const [selected, setSelected] = useState(0);
  const [removeIndex, setRemoveIndex] = useState<number | null>(null);
  const entity = model.entities[Math.min(selected, Math.max(0, model.entities.length - 1))];
  const updatePlant = (index: number, patch: Partial<ReactionWheelPlantRow>) => {
    const rows = model.entities.map((item) => ({ ...item.plant })); rows[index] = { ...rows[index], ...patch } as ReactionWheelPlantRow;
    store.replaceDraft(replaceReactionWheelPlantRows(store.getState().draft, schema, rows));
  };
  const addWheel = () => { const next=addReactionWheel(store.getState().draft,schema); store.replaceDraft(next); setSelected(model.entities.length); };
  const duplicateWheel = (index: number) => { store.replaceDraft(duplicateReactionWheel(store.getState().draft,schema,index)); setSelected(index+1); };
  const moveWheel = (index: number, delta: number) => { const target=index+delta; if(target<0||target>=model.entities.length)return; store.replaceDraft(moveReactionWheel(store.getState().draft,schema,index,target)); setSelected(target); };
  const removeWheel = (index: number) => { store.replaceDraft(removeReactionWheel(store.getState().draft,schema,index)); setSelected(Math.max(0,index-1)); setRemoveIndex(null); };
  const rows = model.entities.map((item) => ({ id: String(item.index), label: item.plant.label || `RW_${item.index}`, axis: vectorText(item.plant.gs_hat_b || []), torque: String(item.plant.u_max_nm), speed: String(item.plant.omega_rpm), hardware: item.hardware ? 'Mapped' : 'Simulation only' }));
  return <><section className="ss-workspace"><Grid fullWidth><Column sm={4} md={8} lg={12}><Stack gap={6}><div className="ss-page-heading"><div><h1>Actuators</h1><p>Author physical actuators coherently. A reaction wheel is one entity whose plant, mounting, HIL identity, controller context, fidelity, and interactions are presented together.</p></div></div>
    <Tile className="ss-rw-workspace"><div className="ss-entity-heading"><div><h2>Reaction wheels</h2><p>The v2 reference vertical slice replaces the legacy three-row duplication. Runtime projection still preserves `reaction_wheels` and `hardware_rw_wheels` exactly.</p></div><div className="ss-action-row"><Button size="sm" onClick={addWheel}>Add wheel</Button><Button kind="tertiary" size="sm" onClick={() => navigate('/integration/hil')}>Open HIL integration</Button></div></div>
      <TableContainer><Table size="md"><TableHead><TableRow>{headers.map((header) => <TableHeader key={header.key}>{header.header}</TableHeader>)}</TableRow></TableHead><TableBody>{rows.map((row, index) => <TableRow key={row.id} className={entity?.index === index ? 'ss-selected-row' : ''}><TableCell><Button kind="ghost" size="sm" {...(entity?.index === index ? { 'aria-current': 'true' as const } : {})} onClick={() => setSelected(index)}>Edit {row.label}</Button></TableCell><TableCell>{row.axis}</TableCell><TableCell>{row.torque}</TableCell><TableCell>{row.speed}</TableCell><TableCell><Tag type={row.hardware === 'Mapped' ? 'green' : 'gray'}>{row.hardware}</Tag></TableCell></TableRow>)}</TableBody></Table></TableContainer>
      {entity ? <div className="ss-rw-detail"><h3>{entity.plant.label || `RW ${entity.index + 1}`}</h3><div className="ss-field-grid">
        <TextInput id="rw-label" labelText="Wheel label" value={entity.plant.label} onChange={(event: React.ChangeEvent<HTMLInputElement>) => updatePlant(entity.index, { label: event.target.value })} />
        <TextInput id="rw-axis" labelText="Spin axis in body frame" value={vectorText(entity.plant.gs_hat_b)} onChange={(event: React.ChangeEvent<HTMLInputElement>) => { try { updatePlant(entity.index, { gs_hat_b: parseVector(event.target.value) }); } catch { /* commit only valid vector */ } }} />
        <TextInput id="rw-position" labelText="Mount position B (m)" value={vectorText(entity.plant.r_wb_b_m)} onChange={(event: React.ChangeEvent<HTMLInputElement>) => { try { updatePlant(entity.index, { r_wb_b_m: parseVector(event.target.value) }); } catch {} }} />
        <NumberInput id="rw-js" label="Rotor inertia (kg·m²)" value={entity.plant.js_kg_m2} min={0} onChange={(_event: unknown, state: { value: string | number }) => updatePlant(entity.index, { js_kg_m2: Number(state.value) })} />
        <NumberInput id="rw-umax" label="Maximum torque (N·m)" value={entity.plant.u_max_nm} min={0} onChange={(_event: unknown, state: { value: string | number }) => updatePlant(entity.index, { u_max_nm: Number(state.value) })} />
        <NumberInput id="rw-speed" label="Initial speed (rpm)" value={entity.plant.omega_rpm} onChange={(_event: unknown, state: { value: string | number }) => updatePlant(entity.index, { omega_rpm: Number(state.value) })} />
        <NumberInput id="rw-max-speed" label="Maximum speed (rpm)" value={entity.plant.omega_max_rpm} min={0} onChange={(_event: unknown, state: { value: string | number }) => updatePlant(entity.index, { omega_max_rpm: Number(state.value) })} />
      </div><div className="ss-entity-actions"><Button kind="ghost" size="sm" disabled={entity.index===0} onClick={() => moveWheel(entity.index,-1)}>Move up</Button><Button kind="ghost" size="sm" disabled={entity.index===model.entities.length-1} onClick={() => moveWheel(entity.index,1)}>Move down</Button><Button kind="ghost" size="sm" onClick={() => duplicateWheel(entity.index)}>Duplicate wheel</Button><Button kind="danger--ghost" size="sm" onClick={() => setRemoveIndex(entity.index)}>Remove wheel</Button></div>
      <div className="ss-hardware-mapping"><div className="ss-entity-heading"><div><h4>Physical HIL mapping</h4><p>This is the runtime <code>hardware_rw_wheels</code> projection for the same physical wheel, not a second wheel inventory.</p></div>{!entity.hardware ? <Button size="sm" kind="tertiary" onClick={() => store.replaceDraft(upsertHardwareMapping(store.getState().draft,schema,entity.index,{...DEFAULT_HARDWARE_REACTION_WHEEL,label:entity.plant.label,wheel_index:entity.index}))}>Add HIL mapping</Button> : <Button size="sm" kind="danger--ghost" onClick={() => store.replaceDraft(removeHardwareMapping(store.getState().draft,schema,entity.index))}>Remove HIL mapping</Button>}</div>
      {entity.hardware && <HardwareMappingEditor value={entity.hardware} onPatch={(patch) => store.replaceDraft(upsertHardwareMapping(store.getState().draft,schema,entity.index,patch))} />}</div>
      </div> : <p>No reaction wheels configured.</p>}
      <Modal open={removeIndex!==null} danger modalHeading="Remove reaction wheel?" primaryButtonText="Remove wheel" secondaryButtonText="Cancel" onRequestClose={() => setRemoveIndex(null)} onRequestSubmit={() => { if(removeIndex!==null)removeWheel(removeIndex); }}><p>The wheel is removed from the plant inventory and any HIL mapping is removed atomically. Remaining wheel indices and HIL mappings are re-indexed together.</p></Modal>
    </Tile>
    <section><h2>Reaction-wheel system</h2><p>All 70 reaction-wheel-related runtime fields are reachable from this one workspace while retaining their true system ownership and the single runtime draft.</p>
      <SemanticFieldGroup title="Plant & catalog authority" description="Cluster enablement, rank, catalog qualification, evidence and jitter." fieldNames={(entityMaps as any).reaction_wheel.groups.plant_catalog} service={service} exclude={["reaction_wheels"]} />
      <SemanticFieldGroup title="Controller & allocator" description="Closed-loop authority, gains, limits, availability, bias and telemetry." fieldNames={(entityMaps as any).reaction_wheel.groups.controller_allocator} service={service} />
      <SemanticFieldGroup title="Controller algorithm linkage" description="Runtime algorithm IDs used by scenario-composed ADCS mode profiles." fieldNames={(entityMaps as any).reaction_wheel.groups.algorithms} service={service} />
      <SemanticFieldGroup title="Command execution & recovery" description="Delay, quantization, friction, thermal/fault behavior and command evidence." fieldNames={(entityMaps as any).reaction_wheel.groups.commands_recovery} service={service} />
      <SemanticFieldGroup title="HIL interface & safety" description="External speed, manual torque, serial bridge, bus safety and evidence." fieldNames={(entityMaps as any).reaction_wheel.groups.hil} service={service} exclude={["hardware_rw_wheels"]} />
      <SemanticFieldGroup title="Interference" description="Cross-component magnetic interference attributable to reaction wheels." fieldNames={(entityMaps as any).reaction_wheel.groups.interference} service={service} />
    </section>
    <StructuredCollectionEditor fieldName="mtbs" title="Magnetorquers" /><StructuredCollectionEditor fieldName="thrusters" title="Thrusters" /><EntityFamilyFieldGroups title="Thruster system" description="Thruster plant enablement, effector identity and optional presentation linkage remain connected to the same physical thruster inventory." fieldNames={(entityMaps as any).thruster.fields} service={service} excludeFields={["thrusters"]} excludeRoutes={["/visualization"]} />
  </Stack></Column></Grid></section><RouteWorkspace route="/spacecraft/actuators" title="Other actuator system settings" description="Non-wheel actuator system configuration uses the same runtime draft." service={service} excludeFields={[...((entityMaps as any).reaction_wheel.groups.plant_catalog), 'reaction_wheels','mtbs','thrusters']} embedded /></>;
}
